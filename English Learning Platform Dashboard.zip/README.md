
  # English Learning Platform Dashboard

  This is a code bundle for English Learning Platform Dashboard. The original project is available at https://www.figma.com/design/khda0j2QcBZikWEtJ0n2ZB/English-Learning-Platform-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  